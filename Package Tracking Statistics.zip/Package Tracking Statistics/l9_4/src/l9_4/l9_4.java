//Jesse Clem 5/29/2019
package l9_4;

import java.util.Arrays;

public class l9_4 {
	//Manually entered data to process
	static int[][] packageShipments = {{ 312, 214, 321, 435, 123, 344, 546}, {220, 535, 342, 352, 364, 245, 355}};
	
	//Main Loop
	public static void main(String[] args) {
		//Output display to console
		System.out.println(Arrays.deepToString(packageShipments));
		System.out.println("Total: " + getTotal(packageShipments));
		System.out.println("Average : " + getAverage(packageShipments));
		System.out.println("Highest Row 1: " + getHighestInRow(packageShipments, 1));
		System.out.println("Lowest Row 1: " + getLowestInRow(packageShipments, 1));
		System.out.println("Row Total 1: " + getRowTotal(packageShipments, 1));
		System.out.println("Column Total 1: " + getColumnTotal(packageShipments, 1));
	}
	
	//Get the total number of shipments from an array
	public static int getTotal(int[][] shipments)
	{
		int total = 0;
		for(int x = 0; x < shipments.length; x++)
		{
			for(int y = 0; y < shipments[x].length; y++)
			total += shipments[x][y];
		}
		return total;
	}

	//Get the average number of shipments from an array
	public static int getAverage(int[][] shipments)
	{
		int average = (getTotal(shipments)) / shipments.length;
		return average;
	}
	
	//Get the highest number of shipments from a select row in a 2D array
	public static int getHighestInRow(int[][] shipments, int row)
	{
		Integer highest = 0;
		for(int i = 0; i < shipments.length; i++)
		{
			Integer shipment = shipments[i][row];
			
			if(i == 0)
			{
				highest = shipment;
			}
				
			if(highest < shipments[i][row])
			{
				highest = shipment;
			}
			
		}
		return highest;
	}
	
	//Get the lowest number of shipments from a select row in a 2D array
	public static int getLowestInRow(int[][] shipments, int column)
	{
		int lowest = 0;
		for(int i = 0; i < shipments.length; i++)
		{
			if(i == 0)
			lowest = shipments[column][i];
			
			
			
			if(lowest > shipments[0][i])
			{
				lowest = shipments[0][i];
			}
		}
		return lowest;
	}
	
	//Get the total number of shipments from a select row in a 2D array
	public static int getRowTotal(int[][] shipments, int row)
	{
		Integer total = 0;
		for(int i = 0; i < shipments.length; i++)
		{
			total += shipments[i][row];
		}
		return total;
	}
	
	//Get the total number of shipments from a select column in a 2D array
	public static int getColumnTotal(int[][] shipments, int column)
	{
		Integer total = 0;
		for(int i = 0; i < shipments[column].length; i++)
		{
			total += shipments[column][i];
		}
		return total;
	}
	//End Functions
}
//End Class l9_4